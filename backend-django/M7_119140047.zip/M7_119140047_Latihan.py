import random
import time
from threading import Thread


class Tim:
    def __init__(self, nama):
        self.nama = nama
        self.win = 0
        self.lose = 0
        self.draw = 0
        self.pts = 0

    def menang(self):
        self.win = self.win + 1
        self.pts = self.pts + 3

    def kalah(self):
        self.lose = self.lose + 1

    def seri(self):
        self.draw = self.draw + 1
        self.pts = self.pts + 1

    def __eq__(self, string):
        return self.nama == string


class LdrBoar:
    def __init__(self, *teams):
        self.teams = []
        for team in teams:
            self.teams.append(Tim(team))

    def tampil(self):
        print('No\tnama\t\tW\tL\tD\tpts')
        for i, team in zip(range(1, len(self.teams) + 1), self.teams):
            print('{}. {}\t\t {}\t{}\t{}\t{}'.format(i,
                                                     team.nama,
                                                     team.win,
                                                     team.lose,
                                                     team.draw,
                                                     team.pts))


class Group(LdrBoar):
    def __init__(self, nama, *args):
        self.nama = nama
        super().__init__(*args)

    def tampil(self):
        print(f'########################## {self.nama.upper()} ##########################')
        super().tampil()

    def match(self, tim1, tim2, winForTim1=None):
        time.sleep(5)
        gacha = random.randint(1, 3)  # pemenang ditentukan dengan random
        print(f'pertandingan {tim1} vs {tim2} telah selesai d')
        if gacha == 1:
            winForTim1 = True
        elif gacha == 2:
            winForTim1 = False
        if (winForTim1 is None):
            for tim in self.teams:
                if tim == tim1 or tim == tim2:
                    tim.seri()
        else:
            if winForTim1:
                for tim in self.teams:
                    if tim == tim1:
                        tim.menang()
                    if tim == tim2:
                        tim.kalah()
            if not winForTim1:
                for tim in self.teams:
                    if tim.nama == tim2:
                        tim.menang()
                    if tim.nama == tim1:
                        tim.kalah()
        self.teams.sort(key=lambda tim: tim.pts, reverse=True)


master = Group('grup B', 'bgsdh', 'Tiseris', 'ochobot', 'perinda', 'nella', 'karisma', 'revoo', 'stokfis', 'judit')


def tanding():
    threads = []
    for i in range(1, len(master.teams)):
        t = Thread(target=master.match,args=(master.teams[0], master.teams[i].nama))
        t.start()
        threads.append(t)

    for thread in threads:
        thread.join()

if __name__=='__main__':
    s = time.perf_counter()
    # print(s)

    tanding()

    f = time.perf_counter()
    # print(f)
    print(f'selesai dalam {f - s} detik')
    print()
    master.tampil()