from threading import Thread
import time

class olah_data:
    def __init__(self, rentang):
        self.rentang = rentang

    def ambil(self):
        print(f'[1] ambil dari data ke : {self.rentang}')
        time.sleep(2)
        print(f'[1] ambil dari data ke : {self.rentang} selesai')
    def sortir(self):
        print(f'[2] sortir dari data ke : {self.rentang}')
        time.sleep(2)
        print(f'[2] sortir dari data ke : {self.rentang} selesai')
    def export(self):
        print(f'[3] export dari data ke : {self.rentang}')
        time.sleep(2)
        print(f'[3] export dari data ke : {self.rentang} selesai')

    def run(self):

        t1= Thread(target=self.ambil())
        t2= Thread(target=self.sortir())
        t3= Thread(target=self.export())

        t1.start()
        t2.start()
        t3.start()

        t1.join()
        t2.join()
        t3.join()

rents = [
    '1 - 10000', '10001 - 20000', '20001 - 30000'
]

start = time.perf_counter()

for rentang in rents:
    t = Thread(target=olah_data(rentang).run)
    t.start()
    

t.join()

finish = time.perf_counter()
print(f'selesai dalam {finish - start} detik')